# -*- coding: utf-8 -*-
"""
Created on Wed Aug  7 17:17:45 2019

@author: Tuna ERTEKİN
"""

import sys
import os

current_path = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_path)
